// Open Panel in New TAB

function openPanel() {
    browser.tabs.create({
	/*url: "https://developer.mozilla.org" */
	url: browser.runtime.getURL('/main.html')
    });
}

browser.browserAction.onClicked.addListener(openPanel);

// Prevent Panel TAB being stored in History

function onVisited(historyItem) {
    if (historyItem.url == browser.runtime.getURL('/main.html')) {
	browser.history.deleteUrl({url: historyItem.url});
    }
}

browser.history.onVisited.addListener(onVisited);


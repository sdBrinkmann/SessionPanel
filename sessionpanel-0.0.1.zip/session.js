import {Session, Box, Store} from "./storage.js"


// Load new Window by on Click

var thisArg = {custom: 'object'};


document.querySelector(".Session-Box").addEventListener('click', async (e) => {
    if (e.target.classList.contains('Box-Item')) {
	const Sessions = await Store.getSessions();
	const pos = parseInt(e.target.dataset.pos);
	browser.windows.create({
	    url: Sessions[pos].url
	});
	//Sessions[pos].url.forEach( element => window.open(element, "new"));
    }
});

function deleteSession() {
    document.querySelector(".Session-Box").addEventListener('click', function(e) {
	if(e.target.id == "delete") {
	    const pos = e.target.parentElement.dataset.pos;
	    if (window.confirm('Delete Session with x Tabs ?'))
		e.target.parentElement.remove();
	    Store.getSessions().then((sessions) => {
		const del = sessions.splice(pos, 1);
		browser.storage.local.set({
		    'sessions': JSON.stringify(sessions)
		});
	    });
	}
    });
}

deleteSession();

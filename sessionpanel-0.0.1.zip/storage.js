// storage.js

export class Session {
    constructor(title, tabs, date, url) {
	this.title = title;
	this.tabs = tabs;
	this.date = date;
	this.url = url;
    }
}

export class Box {
    addBox(Session, pos){
	const Container = document.querySelector('.Session-Box');
	const box = document.createElement('div');
	const Title = document.createElement('p');
	const Delete = document.createElement('p');
	const Info = document.createElement('p');
	Title.innerText += Session.title + " (" + Session.tabs + ")";
	Delete.innerHTML += '&times;';
	Delete.id = "delete";
	Info.innerText = Session.date.toLocaleString();
	Info.className = 'time-stamp';
	box.className = 'Box-Item';
	box.setAttribute('data-pos', pos);
	box.appendChild(Title);
	box.appendChild(Delete);
	box.appendChild(Info);
	Container.appendChild(box);
    }
}

// Local Storage Class

export class Store {
    static async  getSessions() {
	let sessions;
	await browser.storage.local.get('sessions').then( (items) => {
	    //console.log(items);
	    //console.log(Object.keys(items));
	    if(Object.keys(items).length == 0) {
		sessions = [];
	    }
	    
	    else {
		sessions = JSON.parse(items.sessions);
	    }
	});
	return sessions;
    }

    static displaySessions() {
	Store.getSessions().then((sessions) => {
	    sessions.forEach((session, index) => {
		const corect = new Session(session.title, session.tabs, new Date(session.date));
		const box = new Box();
		box.addBox(corect, index);
	    });
	});

    }

    static async addSession(Session) {
	let pos;
	await Store.getSessions().then((sessions) => {

	    sessions.push(Session);
	    browser.storage.local.set({
		'sessions': JSON.stringify(sessions)
	    });
	    pos = sessions.length - 1
	});
	return pos;
    }
    /*
  static addSession(Session) {
	const sessions = Store.getSessions();

	sessions.push(Session);
	browser.storage.local.set('sessions', JSON.stringify(sessions));
	return sessions.length - 1
    }
     */

    static removeSession() {

    }
}


/*
export class Store {
    static getSessions() {
	let sessions;
	if(browser.storage.local.get('sessions') === null)
	    sessions = [];
	else
	    sessions = JSON.parse(browser.storage.local.get('sessions'));
	return sessions;
    }

    static displaySessions() {
	const sessions = Store.getSessions();
	sessions.forEach((session) => {
	    const corect = new Session(session.title, session.tabs, new Date(session.date));
	    const box = new Box();
	    box.addBox(corect);
	});

    }

    static addSession(Session) {
	const sessions = Store.getSessions();

	sessions.push(Session);
	browser.storage.local.set('sessions', JSON.stringify(sessions));
	return sessions.length - 1
    }

    static removeSession() {

    }
}
*/

/*
    static async displaySessions() {
	const sess = await Store.getSessions();

	sess.forEach((session) => {
	    const corect = new Session(sess.title, sess.tabs, new Date(sess.date));
	    const box = new Box();
	    box.addBox(corect);
	});
    }

*/


//export {Session, Box};

// add.js

import {Session, Box, Store} from "./storage.js";

// Get and List TABS

function getWindowTabs() {
    return browser.tabs.query({currentWindow: true});
}

function listTabs(callback) {
    getWindowTabs().then((tabs) => {
	const List = document.getElementById('tabs-list');
	const currentTabs = document.createDocumentFragment();
	List.textContent = '';

	for (let tab of tabs) {
	    const Parent = document.createElement('div');
	    const Icon = document.createElement('img');
	    const Link = document.createElement('a');
	    const Del = document.createElement('img');

	    Parent.className = 'Tab-Item';
	    Icon.src = tab.favIconUrl;
	    Del.src = 'icons/delete-16.png';
	    Del.classList.add('d-b');
	    //Icon.setAttribute('rel', 'icon');
	    //Icon.setAttribute('href', tab.favIconUrl)
	    Link.textContent = tab.title || tab.id;
	    Link.setAttribute('href', tab.url);
	    Link.id = tab.id;
	    Link.classList.add('list-tabs');
	    Parent.appendChild(Icon);
	    Parent.appendChild(Link);
	    Parent.appendChild(Del);
	    currentTabs.appendChild(Parent);
	}

	List.appendChild(currentTabs);
	callback();
    });
}



    listTabs(test);
    //window.alert('test');
linkTabs();
closeTab();

// SWITCH & CLOSE TABS Functionality

function linkTabs() {
        document.querySelector("#tabs-list").addEventListener('click', function(e){
	    if (e.target.classList.contains('list-tabs')) {
		e.preventDefault();
	    //console.log(typeof  e.target.id);
		const ID = parseInt(e.target.id);
		browser.tabs.update(ID, {active: true});
	    }
	});
}

function closeTab() {
    document.querySelector("#tabs-list").addEventListener('click', function(e) {
	if (e.target.classList.contains('d-b')) {
	    const ID = parseInt(e.target.previousSibling.id);
	    browser.tabs.remove(ID);
	    e.target.parentElement.remove();
	}
    });
}

function test() {
document.querySelector(".testButton").onclick = () => {
   browser.tabs.update(4, {active: true});
}
}

// Display Number of TABS 

let No_tabs = browser.tabs.query({currentWindow: true}).then((tabs) => {
    //console.log(tabs);
    document.querySelector(".NO").innerText += " (" + tabs.length + ")";
});

// Pop-up Modal

function addSession() {
    document.querySelector(".add-icon").addEventListener('click', function(e) {

	modal.style.display = "block";
	document.getElementById('session-name').focus();

	//const Container = document.querySelector('.Session-Box');
	//const Box = document.createElement('div')
	//Box.className = 'Box-Item';
	//Container.appendChild(Box);
    });
}

window.onclick = function(event) {
  if (event.target == modal) {
    modal.style.display = "none";
  }
}


addSession();

// Modal

const modal = document.getElementById("myModal");
const span = document.getElementsByClassName("close")[0];


span.onclick = function() {
  modal.style.display = "none";
}



document.getElementById("session-name").onkeypress = function(e){
    if (!e) e = window.event;
    var keyCode = e.keyCode || e.which;
    if(keyCode == '13') {
	let Name = this.value;
	alert(Name);
	modal.style.display = 'none';
	getWindowTabs().then(async (tabs) => {
	    const No_tabs = tabs.length;
	    let url = []
	    for (let tab of tabs) {
		url.push(tab.url);
	    }
	    const session = new Session(Name, No_tabs, new Date(), url);
	    const box = new Box();
	    let  pos = await Store.addSession(session);
	    box.addBox(session, pos);
	});

	    /*
	const Container = document.querySelector('.Session-Box');
	const Box = document.createElement('div');
	const Text = document.createElement('p');
	Text.innerText = this.value;
	Box.className = 'Box-Item';
	Box.appendChild(Text);
	Container.appendChild(Box);
	*/
	document.getElementById("session-name").value = '';
	
    }
}

// DOM Load Event

document.addEventListener('DOMContentLoaded', Store.displaySessions());


/*
const li = document.createElement('li');

li.className = 'collection-item';
li.id = 'new-item';
li.setAttribute('title', 'New Item');
li.appendChild(document.createTextNode('Hello World'));

const link = document.createElement('a')
link.innerHTML = '<i class = "fa fa-remove"></i>';

li.appendChild(link);

document.querySelector('ul').appendChild(li);
*/		       

/*
let Win = window.name;
document.getElementById("win-name").onkeypress = function(e){
    if (!e) e = window.event;
    var keyCode = e.keyCode || e.which;
    if(keyCode == '13') {
	let Name = this.value;
	alert(Name);
	window.document.title = this.value;
    }
}
*/
